# SMS-Message-Spam-Detector
A simple Flask API to detect spam or ham using Python and sklearn
